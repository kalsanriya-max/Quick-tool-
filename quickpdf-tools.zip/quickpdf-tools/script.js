/* QuickPDF Tools — front-end logic
   Uses pdf-lib (creating/editing PDFs) and pdf.js (rendering PDF pages to images).
   Everything runs locally in the browser — no files are uploaded anywhere. */
(function () {
  "use strict";

  /* ---------------------------------------------------------------- */
  /* 1. Tool catalog                                                   */
  /* ---------------------------------------------------------------- */
  const TOOLS = [
    { id: "merge",     icon: "🔗", name: "Merge PDF",         desc: "Combine multiple PDFs into one file, in any order.",           category: "Organize", working: true },
    { id: "split",     icon: "✂️", name: "Split PDF",         desc: "Pull specific pages (e.g. 1,3-5) into a new PDF.",             category: "Organize", working: true },
    { id: "rotate",    icon: "🔄", name: "Rotate PDF",        desc: "Rotate all or selected pages by 90°, 180° or 270°.",           category: "Organize", working: true },
    { id: "pagenum",   icon: "#️⃣", name: "Add Page Numbers",  desc: "Stamp page numbers anywhere on your PDF.",                     category: "Edit",     working: true },
    { id: "img2pdf",   icon: "🖼️", name: "JPG/PNG to PDF",    desc: "Turn one or more images into a single PDF.",                   category: "Convert",  working: true },
    { id: "pdf2jpg",   icon: "📷", name: "PDF to JPG",        desc: "Export every page as a JPG image, zipped for download.",       category: "Convert",  working: true },
    { id: "compress",  icon: "🗜️", name: "Compress PDF",      desc: "Reduce PDF file size for easier sharing.",                     category: "Advanced", working: false },
    { id: "pdf2word",  icon: "📝", name: "PDF to Word",       desc: "Convert PDF pages to an editable Word document.",              category: "Advanced", working: false },
    { id: "word2pdf",  icon: "📄", name: "Word to PDF",       desc: "Convert Word documents into PDF.",                             category: "Advanced", working: false },
    { id: "pdf2ppt",   icon: "📊", name: "PDF to PowerPoint", desc: "Convert PDF pages into editable slides.",                      category: "Advanced", working: false },
    { id: "pdf2excel", icon: "📈", name: "PDF to Excel",      desc: "Extract PDF tables into a spreadsheet.",                       category: "Advanced", working: false },
    { id: "ocr",       icon: "🔍", name: "OCR PDF",           desc: "Make a scanned PDF searchable and selectable.",                category: "Advanced", working: false },
    { id: "edit",      icon: "✏️", name: "Edit PDF",          desc: "Add text, shapes and annotations directly on a page.",         category: "Advanced", working: false },
    { id: "protect",   icon: "🔒", name: "Protect PDF",       desc: "Add a password to lock your PDF.",                             category: "Advanced", working: false },
    { id: "unlock",    icon: "🔓", name: "Unlock PDF",        desc: "Remove a known password from a PDF.",                          category: "Advanced", working: false }
  ];

  /* ---------------------------------------------------------------- */
  /* 2. Small helpers                                                  */
  /* ---------------------------------------------------------------- */
  const $ = (sel, root) => (root || document).querySelector(sel);
  const $$ = (sel, root) => Array.from((root || document).querySelectorAll(sel));

  function downloadBytes(bytes, filename, mime) {
    const blob = new Blob([bytes], { type: mime });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    setTimeout(() => {
      URL.revokeObjectURL(url);
      a.remove();
    }, 1500);
  }

  function fileToArrayBuffer(file) {
    return file.arrayBuffer ? file.arrayBuffer() : new Promise((res, rej) => {
      const r = new FileReader();
      r.onload = () => res(r.result);
      r.onerror = rej;
      r.readAsArrayBuffer(file);
    });
  }

  // Parses strings like "1,3-5,8" into a 0-indexed, de-duplicated page array.
  function parseRanges(str, maxPage) {
    const out = [];
    String(str || "")
      .split(",")
      .map((s) => s.trim())
      .filter(Boolean)
      .forEach((part) => {
        if (part.includes("-")) {
          let [a, b] = part.split("-").map((n) => parseInt(n.trim(), 10));
          if (isNaN(a) || isNaN(b)) return;
          if (a > b) [a, b] = [b, a];
          for (let i = a; i <= b; i++) if (i >= 1 && i <= maxPage) out.push(i - 1);
        } else {
          const n = parseInt(part, 10);
          if (!isNaN(n) && n >= 1 && n <= maxPage) out.push(n - 1);
        }
      });
    return [...new Set(out)];
  }

  function setStatus(el, msg, type) {
    if (!el) return;
    el.textContent = msg || "";
    el.style.color = type === "error" ? "#d63031" : type === "ok" ? "#1a9e5c" : "";
  }

  /* ---------------------------------------------------------------- */
  /* 3. Grid rendering + search                                        */
  /* ---------------------------------------------------------------- */
  function renderGrid(filter) {
    const grid = $("#toolsGrid");
    const empty = $("#empty");
    if (!grid) return;
    const q = (filter || "").trim().toLowerCase();
    const list = TOOLS.filter(
      (t) => !q || t.name.toLowerCase().includes(q) || t.desc.toLowerCase().includes(q)
    );
    grid.innerHTML = list
      .map(
        (t) => `
      <div class="tool" data-id="${t.id}" role="button" tabindex="0">
        <div class="icon">${t.icon}</div>
        <h3>${t.name}</h3>
        <p>${t.desc}</p>
      </div>`
      )
      .join("");
    if (empty) empty.hidden = list.length !== 0;
    $$(".tool", grid).forEach((card) => {
      card.addEventListener("click", () => openModal(card.dataset.id));
      card.addEventListener("keydown", (e) => {
        if (e.key === "Enter" || e.key === " ") {
          e.preventDefault();
          openModal(card.dataset.id);
        }
      });
    });
  }

  /* ---------------------------------------------------------------- */
  /* 4. Modal shell                                                    */
  /* ---------------------------------------------------------------- */
  function ensureModal() {
    if ($("#toolModal")) return;
    const div = document.createElement("div");
    div.id = "toolModal";
    div.className = "modal";
    div.innerHTML = `
      <div class="modal-backdrop" data-close="1"></div>
      <div class="modal-box" role="dialog" aria-modal="true">
        <button class="modal-close" data-close="1" aria-label="Close">&times;</button>
        <div id="modalContent"></div>
      </div>`;
    document.body.appendChild(div);
    div.addEventListener("click", (e) => {
      if (e.target.dataset && e.target.dataset.close) closeModal();
    });
    document.addEventListener("keydown", (e) => {
      if (e.key === "Escape") closeModal();
    });
  }

  function openModal(toolId) {
    const tool = TOOLS.find((t) => t.id === toolId);
    if (!tool) return;
    ensureModal();
    const content = $("#modalContent");
    content.innerHTML = tool.working ? formFor(tool) : placeholderFor(tool);
    if (tool.working) wireUp(tool.id);
    $("#toolModal").classList.add("show");
  }

  function closeModal() {
    const m = $("#toolModal");
    if (m) m.classList.remove("show");
  }

  function placeholderFor(tool) {
    return `
      <h2>${tool.icon} ${tool.name}</h2>
      <p class="modal-help">${tool.desc}</p>
      <div class="notice">This tool needs a conversion engine or backend that isn't wired up in this front-end-only demo, so it's intentionally not faked here. Working tools (Merge, Split, Rotate, Add Page Numbers, JPG/PNG↔PDF) run fully in your browser — no upload needed.</div>`;
  }

  /* ---------------------------------------------------------------- */
  /* 5. Per-tool form markup                                           */
  /* ---------------------------------------------------------------- */
  function formFor(tool) {
    switch (tool.id) {
      case "merge":
        return `
          <h2>🔗 Merge PDF</h2>
          <p class="modal-help">Pick two or more PDFs. They'll be merged in the order selected.</p>
          <label>PDF files<input type="file" id="f_merge" accept="application/pdf" multiple></label>
          <button class="primary full" id="run_merge">Merge PDFs</button>
          <p class="tool-status" id="status_merge"></p>`;
      case "split":
        return `
          <h2>✂️ Split PDF</h2>
          <p class="modal-help">Upload a PDF and enter the pages to extract.</p>
          <label>PDF file<input type="file" id="f_split" accept="application/pdf"></label>
          <label>Pages to keep<input type="text" id="pages_split" placeholder="e.g. 1,3-5"></label>
          <button class="primary full" id="run_split">Split PDF</button>
          <p class="tool-status" id="status_split"></p>`;
      case "rotate":
        return `
          <h2>🔄 Rotate PDF</h2>
          <p class="modal-help">Upload a PDF, choose a rotation and (optionally) which pages.</p>
          <label>PDF file<input type="file" id="f_rotate" accept="application/pdf"></label>
          <label>Rotate by
            <select id="deg_rotate">
              <option value="90">90° clockwise</option>
              <option value="180">180°</option>
              <option value="270">270° clockwise (90° counter-clockwise)</option>
            </select>
          </label>
          <label>Pages (blank = all)<input type="text" id="pages_rotate" placeholder="e.g. 1,3-5"></label>
          <button class="primary full" id="run_rotate">Rotate PDF</button>
          <p class="tool-status" id="status_rotate"></p>`;
      case "pagenum":
        return `
          <h2>#️⃣ Add Page Numbers</h2>
          <p class="modal-help">Upload a PDF to stamp page numbers on every page.</p>
          <label>PDF file<input type="file" id="f_pagenum" accept="application/pdf"></label>
          <label>Position
            <select id="pos_pagenum">
              <option value="bottom-center">Bottom center</option>
              <option value="bottom-right">Bottom right</option>
              <option value="bottom-left">Bottom left</option>
              <option value="top-center">Top center</option>
              <option value="top-right">Top right</option>
            </select>
          </label>
          <label>Start number<input type="number" id="start_pagenum" value="1" min="0"></label>
          <button class="primary full" id="run_pagenum">Add Page Numbers</button>
          <p class="tool-status" id="status_pagenum"></p>`;
      case "img2pdf":
        return `
          <h2>🖼️ JPG/PNG to PDF</h2>
          <p class="modal-help">Pick one or more images. Each image becomes a page, in the order selected.</p>
          <label>Image files<input type="file" id="f_img2pdf" accept="image/jpeg,image/png" multiple></label>
          <button class="primary full" id="run_img2pdf">Convert to PDF</button>
          <p class="tool-status" id="status_img2pdf"></p>`;
      case "pdf2jpg":
        return `
          <h2>📷 PDF to JPG</h2>
          <p class="modal-help">Upload a PDF — every page is exported as a JPG and packed into a ZIP.</p>
          <label>PDF file<input type="file" id="f_pdf2jpg" accept="application/pdf"></label>
          <label>Image quality
            <select id="scale_pdf2jpg">
              <option value="1">Standard</option>
              <option value="2" selected>High</option>
              <option value="3">Very high</option>
            </select>
          </label>
          <button class="primary full" id="run_pdf2jpg">Convert to JPG</button>
          <p class="tool-status" id="status_pdf2jpg"></p>`;
      default:
        return "";
    }
  }

  /* ---------------------------------------------------------------- */
  /* 6. Wiring + processing (pdf-lib / pdf.js)                         */
  /* ---------------------------------------------------------------- */
  function wireUp(id) {
    const { PDFDocument, degrees, rgb, StandardFonts } = window.PDFLib || {};
    const status = (msg, type) => setStatus($("#status_" + id), msg, type);

    if (id === "merge") {
      $("#run_merge").addEventListener("click", async () => {
        const input = $("#f_merge");
        const files = Array.from(input.files || []);
        if (files.length < 2) return status("Please choose at least 2 PDF files.", "error");
        try {
          status("Merging…");
          const out = await PDFDocument.create();
          for (const file of files) {
            const bytes = await fileToArrayBuffer(file);
            const src = await PDFDocument.load(bytes, { ignoreEncryption: true });
            const pages = await out.copyPages(src, src.getPageIndices());
            pages.forEach((p) => out.addPage(p));
          }
          const bytes = await out.save();
          downloadBytes(bytes, "merged.pdf", "application/pdf");
          status(`Done — merged ${files.length} files.`, "ok");
        } catch (err) {
          console.error(err);
          status("Couldn't merge those files: " + err.message, "error");
        }
      });
    }

    if (id === "split") {
      $("#run_split").addEventListener("click", async () => {
        const file = $("#f_split").files[0];
        const rangeStr = $("#pages_split").value;
        if (!file) return status("Please choose a PDF file.", "error");
        try {
          status("Splitting…");
          const bytes = await fileToArrayBuffer(file);
          const src = await PDFDocument.load(bytes, { ignoreEncryption: true });
          const total = src.getPageCount();
          const indices = parseRanges(rangeStr, total);
          if (!indices.length) return status(`Enter valid pages between 1 and ${total}.`, "error");
          const out = await PDFDocument.create();
          const pages = await out.copyPages(src, indices);
          pages.forEach((p) => out.addPage(p));
          const outBytes = await out.save();
          downloadBytes(outBytes, "split.pdf", "application/pdf");
          status(`Done — extracted ${indices.length} page(s) of ${total}.`, "ok");
        } catch (err) {
          console.error(err);
          status("Couldn't split that file: " + err.message, "error");
        }
      });
    }

    if (id === "rotate") {
      $("#run_rotate").addEventListener("click", async () => {
        const file = $("#f_rotate").files[0];
        const deg = parseInt($("#deg_rotate").value, 10);
        const rangeStr = $("#pages_rotate").value;
        if (!file) return status("Please choose a PDF file.", "error");
        try {
          status("Rotating…");
          const bytes = await fileToArrayBuffer(file);
          const doc = await PDFDocument.load(bytes, { ignoreEncryption: true });
          const total = doc.getPageCount();
          const indices = rangeStr.trim() ? parseRanges(rangeStr, total) : doc.getPageIndices();
          if (!indices.length) return status(`Enter valid pages between 1 and ${total}, or leave blank for all.`, "error");
          const pages = doc.getPages();
          indices.forEach((i) => {
            const page = pages[i];
            const current = page.getRotation().angle;
            page.setRotation(degrees((current + deg) % 360));
          });
          const outBytes = await doc.save();
          downloadBytes(outBytes, "rotated.pdf", "application/pdf");
          status(`Done — rotated ${indices.length} page(s).`, "ok");
        } catch (err) {
          console.error(err);
          status("Couldn't rotate that file: " + err.message, "error");
        }
      });
    }

    if (id === "pagenum") {
      $("#run_pagenum").addEventListener("click", async () => {
        const file = $("#f_pagenum").files[0];
        const position = $("#pos_pagenum").value;
        const start = parseInt($("#start_pagenum").value, 10) || 0;
        if (!file) return status("Please choose a PDF file.", "error");
        try {
          status("Stamping page numbers…");
          const bytes = await fileToArrayBuffer(file);
          const doc = await PDFDocument.load(bytes, { ignoreEncryption: true });
          const font = await doc.embedFont(StandardFonts.Helvetica);
          const pages = doc.getPages();
          pages.forEach((page, i) => {
            const { width, height } = page.getSize();
            const label = String(start + i);
            const size = 11;
            const textWidth = font.widthOfTextAtSize(label, size);
            let x, y;
            const margin = 28;
            if (position.startsWith("bottom")) y = margin; else y = height - margin - size;
            if (position.endsWith("center")) x = (width - textWidth) / 2;
            else if (position.endsWith("right")) x = width - margin - textWidth;
            else x = margin;
            page.drawText(label, { x, y, size, font, color: rgb(0.1, 0.12, 0.2) });
          });
          const outBytes = await doc.save();
          downloadBytes(outBytes, "numbered.pdf", "application/pdf");
          status(`Done — numbered ${pages.length} page(s).`, "ok");
        } catch (err) {
          console.error(err);
          status("Couldn't add page numbers: " + err.message, "error");
        }
      });
    }

    if (id === "img2pdf") {
      $("#run_img2pdf").addEventListener("click", async () => {
        const files = Array.from($("#f_img2pdf").files || []);
        if (!files.length) return status("Please choose at least 1 image.", "error");
        try {
          status("Converting…");
          const doc = await PDFDocument.create();
          for (const file of files) {
            const bytes = await fileToArrayBuffer(file);
            const isPng = file.type === "image/png" || /\.png$/i.test(file.name);
            const img = isPng ? await doc.embedPng(bytes) : await doc.embedJpg(bytes);
            const page = doc.addPage([img.width, img.height]);
            page.drawImage(img, { x: 0, y: 0, width: img.width, height: img.height });
          }
          const outBytes = await doc.save();
          downloadBytes(outBytes, "images.pdf", "application/pdf");
          status(`Done — converted ${files.length} image(s).`, "ok");
        } catch (err) {
          console.error(err);
          status("Couldn't convert those images: " + err.message, "error");
        }
      });
    }

    if (id === "pdf2jpg") {
      $("#run_pdf2jpg").addEventListener("click", async () => {
        const file = $("#f_pdf2jpg").files[0];
        const scale = parseFloat($("#scale_pdf2jpg").value) || 2;
        if (!file) return status("Please choose a PDF file.", "error");
        if (typeof JSZip === "undefined") return status("ZIP library failed to load — check your internet connection.", "error");
        try {
          status("Rendering pages…");
          const bytes = await fileToArrayBuffer(file);
          const pdf = await pdfjsLib.getDocument({ data: bytes }).promise;
          const zip = new JSZip();
          for (let i = 1; i <= pdf.numPages; i++) {
            const page = await pdf.getPage(i);
            const viewport = page.getViewport({ scale });
            const canvas = document.createElement("canvas");
            canvas.width = viewport.width;
            canvas.height = viewport.height;
            const ctx = canvas.getContext("2d");
            await page.render({ canvasContext: ctx, viewport }).promise;
            const blob = await new Promise((res) => canvas.toBlob(res, "image/jpeg", 0.92));
            zip.file(`page-${String(i).padStart(2, "0")}.jpg`, blob);
            status(`Rendering page ${i} of ${pdf.numPages}…`);
          }
          const zipBlob = await zip.generateAsync({ type: "blob" });
          downloadBytes(await zipBlob.arrayBuffer(), "pages.zip", "application/zip");
          status(`Done — exported ${pdf.numPages} page(s) as JPG.`, "ok");
        } catch (err) {
          console.error(err);
          status("Couldn't convert that PDF: " + err.message, "error");
        }
      });
    }
  }

  /* ---------------------------------------------------------------- */
  /* 7. Chrome: search, theme, mobile menu                             */
  /* ---------------------------------------------------------------- */
  function initChrome() {
    const search = $("#search");
    if (search) search.addEventListener("input", (e) => renderGrid(e.target.value));

    const themeBtn = $("#themeBtn");
    if (themeBtn) {
      if (localStorage.getItem("qpt-theme") === "dark") {
        document.body.classList.add("dark");
        themeBtn.textContent = "☀";
      }
      themeBtn.addEventListener("click", () => {
        const dark = document.body.classList.toggle("dark");
        themeBtn.textContent = dark ? "☀" : "☾";
        localStorage.setItem("qpt-theme", dark ? "dark" : "light");
      });
    }

    const menuBtn = $("#menuBtn");
    const nav = $("#nav");
    if (menuBtn && nav) {
      menuBtn.addEventListener("click", () => nav.classList.toggle("open"));
    }
  }

  /* ---------------------------------------------------------------- */
  /* 8. Boot                                                           */
  /* ---------------------------------------------------------------- */
  document.addEventListener("DOMContentLoaded", () => {
    renderGrid("");
    initChrome();
    ensureModal();
  });
})();
