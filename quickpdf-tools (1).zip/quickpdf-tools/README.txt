QuickPDF Tools - Working Starter (v2, offline-friendly)

HOW TO RUN
1. Extract the ZIP and keep ALL files and folders together
   (index.html, style.css, script.js, and the vendor/ folder must
   stay in the same place — do not move index.html out on its own).
2. Double-click index.html to open it in Chrome, Edge or Firefox.
   - No internet needed for: Merge PDF, Split PDF, Rotate PDF,
     Add Page Numbers, JPG/PNG to PDF. These use the pdf-lib
     library bundled locally in vendor/pdf-lib.min.js.
   - Internet IS needed for: PDF to JPG only, which loads pdf.js
     from a CDN because it needs a browser worker.
3. If a merge/split/rotate/page-number/image tool still doesn't
   work even with no internet involved, you likely opened the file
   in a way that blocks local scripts. The most reliable fix on any
   OS is to serve the folder instead of double-clicking it:
     Open a terminal in this folder and run:
       python3 -m http.server 8000
     Then visit http://localhost:8000 in your browser.
   This avoids all file:// browser restrictions.

TROUBLESHOOTING
- Tools grid is blank: open the browser console (press F12, click
  "Console"). A red banner will also now appear at the top of the
  page if any script error happens — read what it says.
- A tool button does nothing: make sure a file was actually chosen
  in the file picker before clicking the action button.
- PDF to JPG says the library couldn't load: that tool needs
  internet access to cdnjs.cloudflare.com. Every other tool still
  works without internet.
- Downloads don't appear: check your browser's download-blocked
  notice (usually a small icon in the address bar) and allow
  downloads/pop-ups for this page — PDF to JPG downloads one file
  per page.

WORKING IN THIS VERSION
- Merge PDF
- Split PDF (page selection such as 1,3-5)
- Rotate PDF
- Add Page Numbers
- JPG/PNG to PDF
- PDF page to JPG (needs internet — see above)

ADVANCED PLACEHOLDERS
PDF to Word, Word to PDF, PDF to PowerPoint, PDF to Excel, OCR, Edit, Protect, Unlock and true high-quality compression need additional conversion engines/backend or specialized browser libraries. They are intentionally not faked.

ADSENSE
Replace the placeholder AdSense publisher ID only after you have an actual AdSense account and site approval. Keep ads clearly separated from tool controls and follow Google's current policies. Approval is never guaranteed by code alone.

PRIVACY
The working browser tools above process files locally in the browser — nothing is uploaded to a server. If you later add a server/backend, update the privacy policy to accurately describe uploads, retention, processing and deletion.
